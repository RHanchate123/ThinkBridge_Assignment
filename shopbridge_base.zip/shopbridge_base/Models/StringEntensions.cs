﻿namespace Shopbridge_base.Models
{
    public static class StringEntensions
    {
        public static string DatabaseConnectionString(this Domain.Models.AppSettings.DatabaseConfiguration db, bool isProduction)
        {
            db = new Domain.Models.AppSettings.DatabaseConfiguration();
            string ServerName, DatabaseName;
            ServerName = "localhost";
            DatabaseName = "ShopBridge";
            db.ServerName = ServerName;
            db.DatabaseName = DatabaseName;
            //db.UserId = "STALLION-A\rahul";
            //db.Password = "7798";
            if (isProduction)
                return $"Server={db.ServerName};Database={db.DatabaseName};User ID={db.UserId};Password={db.Password};Encrypt=true;";
            return $"server={db.ServerName};database={db.DatabaseName};trusted_connection=true;Encrypt=false;";
        }
    }
}
