﻿using Microsoft.EntityFrameworkCore;
using Shopbridge_base.Entities;
using System.Threading.Tasks;

namespace Shopbridge_base.Interfaces
{
    public interface IDBContext
    {
        public DbSet<Product_Item> Product { get; set; }
        int SaveChanges();
        Task<int> SaveChangesAsync();

    }
}
