﻿
using Shopbridge_base.Data.Repository;
using Shopbridge_base.Entities;
using Shopbridge_base.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ShopBridge.Dal.Interfaces
{
    public interface IProductRepository: IRepository
    {
        Task<List<Product_Item>> GetAllItemAsync(string searchText);
        Task<Product_Item> GetItemAsync(string name);
        Task<Product_Item> UpdateItemAsync(Product_Item item);
        Task<Product_Item> AddItemAsync(Product_Item item);
        Task<bool> DeleteItemAsync(string itemId);
        Task<bool> IsItemExistsAsync(string itemId);
    }
}
