﻿namespace Shopbridge_base.Domain.Models.AppSettings
{
    public class Class
    {
    }
}
