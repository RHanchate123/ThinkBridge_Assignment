﻿namespace Shopbridge_base.Domain.Models.AppSettings
{
    public class DatabaseConfiguration
    {
        public string ServerName { get; set; }
        public string DatabaseName { get; set; }
        public string UserId { get; set; }
        public string Password { get; set; }

      
    }
}
