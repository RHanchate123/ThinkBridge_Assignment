﻿using Microsoft.EntityFrameworkCore;
using Shopbridge_base.Entities;

namespace ShopBridge_base.Extensions
{
    public static class ShopBridgeModelBuilderExtensions
    {
        public static void ConfigureShopBridgeContext(this ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<Product_Item>(item =>
            {
                item.ToTable("Items");
                item.HasKey(i => i.ID);
                item.HasIndex(i =>  i.Name).IsUnique();
                item.Property(i => i.Name).IsRequired();
                item.Property(i => i.Price).IsRequired();
                item.Property(i => i.Quantity).IsRequired();

            });
        }
    }
}
