﻿using AutoMapper;
using DocumentFormat.OpenXml.Office.CustomUI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ShopBridge.Dal.Interfaces;
using Shopbridge_base.Domain.Models;
using Shopbridge_base.Entities;
using ShopBridge_base.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mime;
using System.Threading.Tasks;

namespace Shopbridge_base.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private ILogger<ProductsController> _controller;
        private readonly IMapper _mapper;
        public IProductRepository _iRepository;
        public ProductsController(IProductRepository repository, ILogger<ProductsController> controller) //IProductRepository
        {
            _iRepository = repository;
            _controller = controller;
        }

        [HttpPost]
        [Consumes(MediaTypeNames.Application.Json)]
        public async Task<IActionResult> PostProduct(Product product)
        {
            try
            {
                var exists = await _iRepository.IsItemExistsAsync(product.Name);
                if (exists)
                {
                    var err = $"Item with given name already exists.";
                    _controller.LogWarning(err);
                    return new ConflictResult();
                }
                var newProductItem = new Product_Item();
                
                newProductItem.Name = product.Name;
                newProductItem.Description = product.Description;
                newProductItem.Price = product.Price;
                newProductItem.Quantity = product.Quantity;
                await _iRepository.AddItemAsync(newProductItem);
                await _iRepository.SaveAsync();
                return Ok(new { message = "Item Inserted successfully" });

            }
            catch (Exception e)
            {
                _controller.LogError($"Error while creating item: {e}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Error while creating item");
            }
            
        }

        [HttpGet]
        public async Task<ActionResult> GetProducts(string searchText = null)
        {
            try
            {
                var item = await _iRepository.GetAllItemAsync(searchText);

                var count = item.Count;

                return new OkObjectResult(item);
            }
            catch (Exception ex)
            {
                _controller.LogError($"error while geting all item information: {ex}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "error while  geting all items information");
            }
        }

        [HttpDelete("{name}")]
        public async Task<IActionResult> DeleteProduct(string name)
        {
            try
            {
                var user = await _iRepository.GetItemAsync(name);

                if (user == null)
                {
                    _controller.LogWarning($"Item with given name: {name} doesn't exists in the store.");
                    return NotFound();
                }
                // item can delete their own account and admins can delete any account
                var deleted = await _iRepository.DeleteItemAsync(name);
                if (!deleted)
                {
                    var error = $"Failed to delete item with name {name}";
                    _controller.LogError(error);
                    return new BadRequestObjectResult(error);
                }
                await _iRepository.SaveAsync();
                return Ok(new { message = "Item Deleted successfully" });

            }
            catch(Exception e)
            {
                _controller.LogError($"error while deleting item : {e}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "error while delting item");
            }

        }

        [HttpPut]
        [Consumes(MediaTypeNames.Application.Json)]
        public async Task<IActionResult> UpdateAsync([FromBody] Product item)
        {
            try
            {
                var name = item.Name;
                var existingItem = await _iRepository.GetItemAsync(name);

                if (existingItem == null)
                {
                    _controller.LogWarning($" Item name :{name} doesn't exists in the store.");
                    return NotFound();
                }

                existingItem.Name = item.Name;
                existingItem.Description = item.Description;
                existingItem.Price = item.Price;
                existingItem.Quantity = item.Quantity;
                //var entityToUpdate = item;
               
                await _iRepository.UpdateItemAsync(existingItem);
                return Ok(new { message = "Item Update successfully" });
            }



            catch (Exception ex)
            {
                _controller.LogError($"error while updating item : {ex}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "error while delting Item");
            }
        }
    }
}
