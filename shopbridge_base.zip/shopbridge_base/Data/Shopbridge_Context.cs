﻿using IdentityServer4.EntityFramework.Options;
using Microsoft.EntityFrameworkCore;
using Shopbridge_base.Entities;
using ShopBridge_base.Extensions;
using System.Threading.Tasks;

namespace Shopbridge_base.Data
{
    public class Shopbridge_Context : DbContext
    {
        private readonly ConfigurationStoreOptions _storeOptions;
        public Shopbridge_Context() : this("server=(local);database=ShopBridge;trusted_connection=yes;".StrToContextOptions<Shopbridge_Context>(),
           new ConfigurationStoreOptions())
        {
        }

        public Shopbridge_Context (DbContextOptions<Shopbridge_Context> options, ConfigurationStoreOptions storeOptions)
            : base(options)
        {
            _storeOptions = storeOptions;
        }

        public DbSet<Product_Item> Product { get; set; }

        public Task<int> SaveChangesAsync()
        {
            return base.SaveChangesAsync();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ConfigureShopBridgeContext();
        }
    }
}
