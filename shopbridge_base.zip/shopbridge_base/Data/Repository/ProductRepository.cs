﻿using Microsoft.EntityFrameworkCore;
using ShopBridge.Dal.Interfaces;
using Shopbridge_base.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shopbridge_base.Data.Repository
{
    public class ProductRepository: Repository, IProductRepository
    {
        public readonly Shopbridge_Context _dbContext;

        public ProductRepository(Shopbridge_Context dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }


        public async Task<Product_Item> AddItemAsync(Product_Item Item)
        {
            await _dbContext.Product.AddAsync(Item);
            return Item;
        }

        public Task<bool> IsItemExistsAsync(string name)
        {
            return _dbContext.Product?.AsNoTracking().AnyAsync(u => u.Name.ToLower() == name.ToLower());
        }

        public async Task<List<Product_Item>> GetAllItemAsync(string searchText)
        {
            var query = _dbContext.Product
                .AsNoTracking();

            if (!string.IsNullOrWhiteSpace(searchText))
            {
                searchText = searchText.ToLower();
                query = _dbContext.Product.Select(p => p);
                
                    
            }

            query = query.OrderBy(u => u.Name);

            var Items = await query.ToListAsync();

            return new List<Product_Item>(Items);
        }

        public async Task<Product_Item> GetItemAsync(string name)
        {
            var Item = await _dbContext.Product
            .AsNoTracking()
            .Where(u => u.Name.ToLower() == name.ToLower())
            .FirstOrDefaultAsync();
            return Item;
        }

        public async Task<bool> DeleteItemAsync(string name)
        {
            var ItemTobeDeleted = await _dbContext.Product.Where(u => u.Name.ToLower() == name.ToLower())
             .FirstOrDefaultAsync();
            if (ItemTobeDeleted != null)
            {
                _dbContext.Product.Remove(ItemTobeDeleted);
                return true;
            }

            return false;
        }

        public async Task<Product_Item> UpdateItemAsync(Product_Item Item)
        {
            _dbContext.Entry(Item).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
            return Item;
        }
    }
}