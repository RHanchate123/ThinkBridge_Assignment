﻿
using Shopbridge_base.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Shopbridge_base.Interfaces
{
    public interface IRepository
    {
        void Save();
        Task SaveAsync();

    }
}
